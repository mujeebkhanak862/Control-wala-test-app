# GitHub se APK, Windows EXE aur Linux DEB build karna

## 1) Repository ka sahi structure

ZIP ke andar `universal_device_agent` folder ke **andar ka tamam content** repository ke root mein hona chahiye. `.github` folder bhi root par ho. Misal:

- `.github/workflows/ci.yml`
- `shared_app/pubspec.yaml`
- `control_api/pubspec.yaml`
- `scripts/package_linux_deb.sh`
- `installers/windows/universal_device_agent.iss`

Ghalat structure: `universal_device_agent/.github/workflows/ci.yml` jab repository root se ek aur `universal_device_agent` folder andar ho. GitHub Actions workflow tab nahi chalega jab `.github` repository root par na ho.

## 2) GitHub par

1. GitHub par naya repository banao.
2. Is ZIP ko apne phone par extract karo.
3. Extracted `universal_device_agent` folder ke **andar ki files/folders** repository root mein upload karo. Sirf ZIP file upload mat karna.
4. Upload ke baad repository ke root par `.github`, `shared_app`, `control_api`, `scripts` aur `installers` dikhne chahiye.
5. `Actions` tab kholo. Agar prompt aaye to workflows enable karo.
6. `CI` workflow select karke `Run workflow` dabao. Ya kisi commit/push par yeh khud chal jayega.
7. Run ke logs mein green check ka intezar karo. Red X aaye to job khol kar sab se pehla error dekho.

## 3) Build files kahan milengi

Successful workflow ke baad `Actions` > successful run > `Artifacts` se download karo:

- `device-agent-debug-apk` — Android APK
- `device-agent-windows` — Windows installer EXE aur app files
- `device-agent-linux-deb` — Linux `.deb` package

Build ho jana real device par har feature ke chalne ki guarantee nahi. Pehle debug APK ko test karo. Windows EXE sirf Windows computer par run hoti hai; Linux DEB Linux/compatible Chromebook Linux environment ke liye hai.
