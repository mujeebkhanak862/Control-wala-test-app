# Universal Device Agent — GitHub se APK aur OS apps build karna

Is ZIP mein project files repository-root layout mein hain. ZIP ko GitHub par as-is upload karne ke bajaye pehle extract karein. Extract karne ke baad `shared_app`, `control_api`, `scripts`, `installers`, aur `.github` folders seedhe project root mein hone chahiye.

## Aasaan tareeqa
1. GitHub par naya repository banayein.
2. Is ZIP ko phone/PC par extract karein. Hidden `.github` folder bhi upload karein.
3. Extracted folder ke andar ki tamam files/folders repository ke root mein upload karein — outer folder ko dobara nest na karein.
4. GitHub repository mein **Actions** tab kholein.
5. **Build All Apps** workflow select karein aur **Run workflow** dabayein.
6. Run complete hone par neeche **Artifacts** se file download karein.

## Kaunsi file milegi?
- `Android-APK`: testing ke liye Android debug APK.
- `Windows-App-ZIP`: Windows release app ki files; ZIP extract karke `device_agent.exe` chalayein.
- `Linux-DEB`: Ubuntu/Debian compatible `.deb` package.

## Zaroori baatein
- Build GitHub ke cloud runners par hota hai; aapko Android Studio install karne ki zaroorat nahi.
- APK debug build hai, Play Store release/signing ke liye nahi.
- App ko Control API backend chahiye. `CONTROL_API_URL` repository variable set na ho to build default `http://localhost:8080` use karega, jo phone/PC se hosted backend ko point nahi karta. Apne deployed backend ka URL set karein: **Settings → Secrets and variables → Actions → Variables → New repository variable → Name: `CONTROL_API_URL`**. Production use mein HTTPS URL rakhein.
- Windows output portable folder ZIP hai, signed installer nahi. Linux `.deb` package x86-64/amd64 ke liye hai.
- Workflow source code ko compile karne ki koshish karta hai; successful build ki guarantee nahi. GitHub Actions run ke logs se actual errors check karein.
